#ifndef _ASSIGN3_FUNCTARRAY_H_
#define _ASSIGN3_FUNCTARRAY_H_

#include <stdio.h>
#include<stdint.h>
/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define MAX 200
#define CHECK_OK 0
#define CHECK_NOK 1


/*******************************************************************************
 * API
 ******************************************************************************/
/*!
 * @importMatrix - Import function matrix
 *
 * @param matrix -  The matrix needs to be entered
 * @param g_row - Variable contain the value of Row
 * @param g_col - Variable contain the value of Col
 *
 * @return - Not returning the value of the function
 */
void importMatrix(float matrix[][MAX], int g_row,int g_col);
/*!
 * @exportMatrix - The matrix print function is entered
 *
 * @param matrix -  The matrix needs to be entered
 * @param g_row - Variable contain the value of Row
 * @param g_col - Variable contain the value of Col
 *
 * @return - Not returning the value of the function
 */
void exportMatrix(float matrix[][MAX],int g_row,int g_col);
/*!
 * @checkSumMatrix - The function calculates the sum of two matrices
 *
 * @return - Not returning the value of the function.
 */
int checkSumMatrix();
/*!
 * @sumMatrix - The function Calculates the sum of two matrices
 *
 * @param matrixA - Matrix A.
 * @param matrixB - Matrix B
 * @param matrixC - Matrix C
 *
 * @return - Not returning the value of the function.
 */
void sumMatrix(float matrixA[][MAX],float matrixB[][MAX], float matrixC[MAX][MAX]);
/*!
 * @mulMatrix - Function multiplies by 2 matrices
 *
 * @param matrixA - Matrix A.
 * @param matrixB - Matrix B
 * @param matrixC - Matrix C - matrix results
 * @param g_rowA - Row of matrix A
 * @param g_colA - Col of matrix B.
 * @param g_colB - Col of matrix C.
 *
 * @return - Not returning the value of the function.
 */
void mulMatrix(float matrixA[][MAX], float matrixB[][MAX], float matrixC[][MAX],int g_rowA, int g_colB,int g_colA);

/*!
 * @checkMul2matrix - prints the case of two imported matrices.
 *
 * @param matrixA - Matrix A.
 * @param matrixB - Matrix B
 * @param matrixC - Matrix C
 *
 * @return - Not returning the value of the function.
 */
void checkMul2matrix(float matrixA[][MAX],float matrixB[][MAX], float matrixC[][MAX]);
/*!
 * @checkMatrix - checks whether two matrices have been entered.
 *
 * @param g_rowA - Row of matrix A
 * @param g_colA - Col of matrix A.
 * @param g_rowA - Row of matrix B
 * @param g_colA - Col of matrix B.
 *
 * return - tra ve 1 neu dung
 */
int checkMatrix(int g_rowA,int g_colA,int g_rowB, int g_colB);


#endif /* _ASSIGN3_FUNCTARRAY_H_ */

