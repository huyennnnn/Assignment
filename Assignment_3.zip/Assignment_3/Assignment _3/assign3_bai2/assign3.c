
#include"assign3_functArray.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/

/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/
/* Declare global variables */
int g_rowA = 0;
int g_colA = 0;
int g_rowB = 0;
int g_colB = 0;
/*******************************************************************************
 * Code
 ******************************************************************************/

int main()
{
    float matrixA[MAX][MAX];
    float matrixB[MAX][MAX];
    float matrixC[MAX][MAX];
    int i = 0;
    int j = 0;
/* Enter the row and column values of the input deviation*/
    do
    {
    	printf("\nMatrix A Row:");
        scanf("%d",&g_rowA);
        printf("\nMatrix A Collumn:");
        scanf("%d",&g_colA);
	}while(g_rowA <=0 ||g_colA <= 0);
	do
    {
        printf("\nMatrix B Row:");
        scanf("%d",&g_rowB);
        printf("\nMatrix B Collumn:");
        scanf("%d",&g_colB);
	}while(g_rowB <=0|| g_colB <=0);
    

/* Enter the value of the elements of the input matrix*/
    printf("\nImport Matrix A:");
    importMatrix(matrixA,g_rowA,g_colA);
    printf("\nImport Matrix B:");
    importMatrix(matrixB,g_rowB,g_colB);

/* Print out the imported matrix screen */
    printf("\nMatrix A:");
    exportMatrix(matrixA,g_rowA,g_colA);
    printf("\nMatrix B:");
    exportMatrix(matrixB,g_rowB,g_colB);

/* Check whether two matrices are added together*/
    if(checkSumMatrix())
    {
    	printf("\nMatrix A, Matrix B can add together");
    }
    else
    {
        printf("\nMatrix A, Matrix B can't add together"); 
    }
/* Check whether two matrices are multiply and print out the screen */
    switch(checkMatrix(g_rowA,g_colA,g_rowB,g_colB))
    {
        case 1:/* A * B OK and B *A OK*/
            printf("\nMatrix A and Matrix B can multi together");
            break;

        case 2:/*A *B OK and B * A NOT OK*/
            printf("\nMatrix A can multi Matrix B,Matrix B can't multi Matrix A");
            break;

        case 3:/* A * B NOT OK, B * A OK*/
            printf("\nMatrix B can multi Matrix A,Matrix A can't multi Matrix B");
            break;

        case 4:/* A * B and B * A NOT OK*/
            printf("\nMatrix A and Matrix B can't multi together");
            break;

        default:
            break;
    }
/* The function calculates the sum of two matrices */
    sumMatrix(matrixA,matrixB,matrixC);
/* The function checks whether two matrices are multiply or not */
    checkMul2matrix(matrixA,matrixB,matrixC);
}

/* The function enters two matrices from the keyboard */
void importMatrix(float matrix[][MAX], int g_row,int g_col)
{
    int i = 0;
    int j = 0;

/* The variable i runs from 0 to the end of the row */
    for(i = 0; i< g_row; i++)
    {
        for(j = 0; j< g_col; j++)/* The variable j runs from 0 to the end of the col */
        {
            printf("\n\tMatrix[%d][%d]: ",i,j);
            scanf("%f",&matrix[i][j]);
        }
    }
}
/* The function prints the matrix just entered the screen */
void exportMatrix(float matrix[][MAX],int g_row,int g_col)
{
    int i = 0;
    int j = 0;
    for(i = 0; i< g_row; i++)/* The variable i runs from 0 to the end of the row */
    {
        printf("\n");
        for(j = 0; j< g_col; j++)/* The variable j runs from 0 to the end of the col */
        {
            printf("\t%.3f",matrix[i][j]);
        }
    }
}

/* The function checks to see if two matrices are added.*/
int checkSumMatrix()
{
    if(g_rowA = g_rowB && g_colA == g_colB) return CHECK_OK;
    return CHECK_NOK;
}

/* Calculates the sum of two matrices */
void sumMatrix(float matrixA[][MAX],float matrixB[][MAX], float matrixC[MAX][MAX])
{
    int i = 0;
    int j = 0;
    if(!checkSumMatrix())
    {
        printf("\nMatrix A+B:");
        printf("\n\tN/A");
    }
    else
    {
        for(i = 0; i< g_rowA; i++)
        {
            for(j = 0; j< g_colA; j++)
            {
                matrixC[i][j] = matrixA[i][j]+matrixB[i][j];
            }
        }
/* Print out the result matrix screen */
        printf("\nMatrix A+B:");
        for(i = 0; i < g_rowA; i++)
        {
        	printf("\n");
        	for(j = 0; j< g_colA; j++)
        	{
        		printf("%.3f",matrixC[i][j]);
			}
		}
    }
}
/* Function multiplies by 2 matrices */
void mulMatrix(float matrixA[][MAX], float matrixB[][MAX], float matrixC[][MAX],int g_rowA, int g_colB,int g_colA)
{
    int i = 0;
    int j = 0;
    int k = 0;
    int sum = 0;

    for(i = 0; i<g_rowA; i++)
    {
        for(j = 0; j<g_colB; j++)
        {
            /* Assign the element c[i][j] = 0*/
            for(k = 0; k<g_colA; k++)
            {
                sum += matrixA[i][k]*matrixB[k][j];/*Execute  matrix A and B assignment to matrix C */
            }
            matrixC[i][j] = sum;
        }
    }
}

/* The function prints the case of two imported matrices. */
void checkMul2matrix(float matrixA[][MAX],float matrixB[][MAX], float matrixC[][MAX])
{
    switch(checkMatrix(g_rowA,g_colA,g_rowB,g_colB))
    {
        case 1:/* A * B OK and B *A OK*/
            printf("\nMatrix A * B:");
            /* multiply the two matrices just entered*/
            mulMatrix(matrixA,matrixB,matrixC,g_rowA,g_colB,g_colA);
            /* Print out the result matrix screen */
            exportMatrix(matrixC,g_rowA,g_colB);

            printf("\nMatrix B * A:");
            /* multiply the two matrices just entered*/
            mulMatrix(matrixB,matrixA,matrixC,g_rowB,g_colA,g_colB);
            /* Print out the result matrix screen */
            exportMatrix(matrixC,g_rowB,g_colA);
            break;

        case 2:/*A *B OK and B * A NOT OK*/
            printf("\nMatrix A * B:");
            /* multiply the two matrices just entered*/
            mulMatrix(matrixA,matrixB,matrixC,g_rowA,g_colB,g_colA);
            /* Print out the result matrix screen */
            exportMatrix(matrixC,g_rowA,g_colB);
            printf("\nMatrix B * A:");
            printf("\n\tN/A");
            break;

        case 3:/* A * B NOT OK, B * A OK*/
            printf("\nMatrix A * B:");
            printf("\n\tN/A");
            printf("\nMatrix B * A:");
            /* multiply the two matrices just entered*/
            mulMatrix(matrixB,matrixA,matrixC,g_rowB,g_colA,g_colB);
            /* Print out the result matrix screen */
            exportMatrix(matrixC,g_rowB,g_colA);
            break;

        case 4:/* A * B and B * A NOT OK*/
            printf("\nMatrix A * B:");
            printf("\n\tN/A");
            printf("\nMatrix B * A:");
            printf("\n\tN/A");
            break;

        default:
            break;
    }
}

/* The function checks whether two matrices have been entered.*/
int checkMatrix(int g_rowA,int g_colA,int g_rowB, int g_colB)
{
    if(g_colA == g_rowB && g_colB == g_rowA)/* A * B OK and B *A OK*/
    {
        return 1;
    }
    else if(g_colA == g_rowB && g_colB != g_rowA)/*A *B OK and B * A NOT OK*/
    {
        return 2;
    }
    else if(g_colA != g_rowB && g_colB == g_rowA)/* A * B NOT OK, B * A OK*/
    {
        return 3;
    }
    else if(g_colA != g_rowB && g_colB != g_rowA)/* A * B and B * A NOT OK*/
    {
        return 4;
    }
}
