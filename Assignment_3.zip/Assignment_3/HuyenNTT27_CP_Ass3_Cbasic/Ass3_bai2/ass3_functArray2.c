
#include"ass3_functArray2.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define MAX 100

/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/
uint8_t g_rowA = 0;
uint8_t g_colA = 0;
uint8_t g_rowB = 0;
uint8_t g_colB = 0;


/*******************************************************************************
 * Code
 ******************************************************************************/
int main()
{
	float matrixA[MAX][MAX];
	float matrixB[MAX][MAX];
	float matrixC[MAX][MAX];
	uint8_t i = 0;
	uint8_t j = 0;
	
	printf("\nMatrix A Row:");
	scanf("%d",&g_rowA);
	printf("\nMatrix A Collumn:");
	scanf("%d",&g_colA);
	printf("\nMatrix B Row:");
	scanf("%d",&g_rowB);
	printf("\nMatrix B Collumn:");
	scanf("%d",&g_colB);
	
	printf("\nImport Matrix A:");
	importMatrix(matrixA,&g_rowA,&g_colA);
	printf("\nImport Matrix B:");
	importMatrix(matrixB,&g_rowB,&g_colB);
	printf("\nMatrix A:");
	exportMatrix(matrixA,&g_rowA,&g_colA);
	printf("\nMatrix B:");
	exportMatrix(matrixB,&g_rowB,&g_colB);
//	checkMul2matrix(matrixA,matrixB, matrixC);
//	mulMatrix(matrixA,matrixB,matrixC);
}

void importMatrix(float matrix[][MAX], uint8_t *g_row,uint8_t *g_col)
{
	uint8_t i = 0u;
	uint8_t j = 0u;
	
	for(i = 0; i< *g_row; i++)
	{
		for(j = 0; j< *g_col; j++)
		{
			printf("\n\tMatrix[%d][%d]: ",i,j);
			scanf("%f: ",&matrix[i][j]);
		}
	}
}
void exportMatrix(float matrix[][MAX],uint8_t *g_row,uint8_t *g_col)
{
	uint8_t i = 0u;
	uint8_t j = 0u;
	for(i = 0; i< *g_row; i++)
	{
		printf("\n");
		for(j = 0; j< *g_col; j++)
		{
			printf("\t%.3f",matrix[i][j]);
		}
	}
}

int checkSumMatrix()
{
	if(g_rowA == g_rowB && g_colA == g_colB) return 1;
	return 0;
}

void sumMatrix(float matrixA[][MAX],float matrixB[][MAX], float matrixC[MAX][MAX])
{
	uint8_t i = 0u;
	uint8_t j = 0u;
	if(checkSumMatrix())
	{
		
		for(i = 0; i< g_rowA; i++)
		{
			for(j = 0; j< g_colA; j++)
			{
				matrixC[i][j] = matrixA[i][j]+matrixB[i][j];
			}
		}
		printf("\nMatrix A, Matrix B cant add together");
		printf("\nMatrix A+B:");
		for(i = 0; i< g_rowA; i++)
		{
			printf("\n");
			for(j = 0; j< g_colA; j++)
			{
				printf("%.3f",matrixC[i][j]);
			}
		}
	}
	else
	{
		printf("\nMatrix A, Matrix B cant add together");
	}
	
}

//void mulMatrix(float matrixA[][MAX],float matrixB[][MAX], float matrixC[MAX][MAX],uint8_t g_rowA,uint8_t g_colA,uint8_t g_colB)
//{
//	uint8_t i = 0u;
//	uint8_t j = 0u;
//	uint8_t k = 0u;
//	for(i = 0; i< g_rowA; i++)
//	{
//	 	for(j = 0; j< g_colB; j++)
//	 	{
//		  	matrixC[i][j] = 0;
//		  	for(k = 0; k< g_colA; k++)
//		  	{
//		  		matrixC[i][j] += matrixA[i][k]*matrixB[k][j];
//	  		}
//  		}
//	}
//	for(i = 0; i< g_rowA; i++)
//	{
//		printf("\n");
//		for(j = 0; j< g_colB; j++)
//		{
//			printf("\t%.3f",matrixC[i][j]);
//		}
//	}
//}
//void checkMul2matrix(float matrixA[][MAX],float matrixB[][MAX], float matrixC[MAX][MAX])
//{
//	switch(checkMulMatrix(g_rowA,g_colA,g_rowB,g_colB))
//	{
//		case 1:
//			printf("\n Matrix A and Matrix B can multi together");
//			printf("\nMatrix A * B:");
//			mulMatrix(matrixA,matrixB,matrixC);
//			printf("\nMatrix B * A:");
//			mulMatrix(matrixB,matrixA,matrixC);
//		case 2:
//			printf("\n Matrix A can multi Matrix B,Matrix B can't multi Matrix A'");
//			printf("\nMatrix A * B:");
//			mulMatrix(matrixA,matrixB,matrixC);
//		case 3:
//			printf("\n Matrix B can multi Matrix A,Matrix A can't multi Matrix B'");
//			printf("\nMatrix B * A:");
//			mulMatrix(matrixB,matrixA,matrixC);
//		case 4:
//			printf("\n Matrix A and Matrix B can't multi together");
//		default:
//			break;
//	}
//}
//int checkMulMatrix(uint8_t g_rowA,uint8_t g_colA,uint8_t g_rowB,uint8_t g_colB)
//{
//	uint8_t i = 0u;
//	uint8_t j = 0u;
//	if(g_colA == g_rowB && g_colB == g_rowA)
//	{
//		return 1;
//	}
//	else if(g_colA == g_rowB && g_colB != g_rowA)
//	{
//		return 1;
//	}
//	else if(g_colA != g_rowB && g_colB == g_rowA)
//	{
//		return 1;
//	}
//	else if(g_colA != g_rowB && g_colB != g_rowA)
//	{
//		return 1;
//	}
//}
