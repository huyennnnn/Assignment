#ifndef _HEADER_FILENAME_H_
#define _HEADER_FILENAME_H_
#include <stdio.h>
#include<stdint.h>
/*******************************************************************************
 * Definitions
 ******************************************************************************/


/*******************************************************************************
 * API
 ******************************************************************************/
/*!
 * @importMatrix - Ham in nhap ma tran
 *
* @param matrix - Ma tran can nhap vao                 
* @param g_row - Bien con tro de chua gia tri cua Hang
* @param g_col - Bien con tro de chua gia tri cua Cot 
* @return - Khong tra ve gia yti cua ham
 */
void importMatrix(float matrix[][MAX], uint8_t *g_row,uint8_t *g_col);
/*!
 * @exportMatrix - Ham in ra ma tran vua nhap
 *
 * @param matrix - Ma tran can in ra
 * @param g_row - Bien con tro de chua gia tri cua Hang
 * @param g_col - Bien con tro de chua gia tri cua Cot
 *
 * @return <Mo ta cac gia tri tra ve>.
 */
void exportMatrix(float matrix[][MAX],uint8_t *g_row,uint8_t *g_col);
/*!
 * @mulMatrix - Thuc hien nhan ma tran A vs B
 *
 * @param matrixA - Ma tran A.
 * @param matrixB - Ma tran B
 * @param matrixC - Ma tran C
  * @param g_rowA - Hang cua ma tran A
 * @param g_colA - Cot cua ma tran A.
 * @param g_colB - Cot cua ma tran B.
 *
 * @return <Mo ta cac gia tri tra ve>.
 */
void mulMatrix(float matrixA[][MAX],float matrixB[][MAX], float matrixC[MAX][MAX],uint8_t g_rowA,uint8_t g_colA,uint8_t g_colB);
/*!
 * @sumMatrix - Ham tinh tong cua ma tran A vs B
 *
 *
 * @return - Khong tra ve gia tri cua ham
 */
void sumMatrix();
/*!
 * @checkMul2matrix - Ham kiem tra cac truong hop cua 2 ma tran A vs B va in ra cac truong hop
 *
 * @param matrixA - Ma tran A.
 * @param matrixB - Ma tran B
 * @param matrixC - Ma tran C
 *
 * @return - khong tra ve gia tri cua ham.
 */
void checkMul2matrix(float matrixA[][MAX],float matrixB[][MAX], float matrixC[MAX][MAX]);
/*!
 * @checkMulMatrix - Ham kiem tra ma tran A va B
 *
 * @param g_rowA - Hang cua ma tran A
 * @param g_colA - Cot cua ma tran A.
 * @param g_rowB - Hang cua ma tran B
 * @param g_colB - Cot cua ma tran B.
 *
 * return - tra ve 1 neu dung
 */
int checkMulMatrix(uint8_t g_rowA,uint8_t g_colA,uint8_t g_rowB,uint8_t g_colB);
/*!
 * @sumMatrix - ham tinh tong 2 ma tran
 *
 * @param matrixA - Ma tran A.
 * @param matrixB - Ma tran B
 * @param matrixC - Ma tran C
 *
 * @return - khong tra ve gia tri cua ham.
 */
void sumMatrix(float matrixA[][MAX],float matrixB[][MAX], float matrixC[MAX][MAX]);

#endif /* _HEADER_FILENAME_H_ */
