#ifndef _ASS3_FUNCTARRAY_H_
#define _ASS3_FUNCTARRAY_H_

#include <stdio.h>
/*******************************************************************************
 * Definitions
 ******************************************************************************/

/*******************************************************************************
 * API
 ******************************************************************************/
/*!
 * @checkInput - kiem tra gia tri chu vi va duong cheo
 *
 * @param g_perimeter - Bien luu gia tri chu vi.
 * @param g_diagonal_line - Bien luu gia tri duong cheo.
 *
 * @return - tra ve 0 neu nhap sai, tra ve 1 neu nhap dung.
 */
int checkInput(float g_perimeter,float g_diagonal_line);
/*!
 * @calAcreage - Ham tinh dien tich hinh chu nhat
 *
 * @param g_acreage - Bien luu gia tri dien tich
 * @param g_perimeter - Bien luu gia tri chu vi.
 * @param g_diagonal_line - Bien luu gia tri duong cheo.
 *
 * @return - khong yeu cau tra ve gia tri.
 */
void calAcreage(float g_acreage, float g_perimeter,float g_diagonal_line);

#endif /* _ASS3_FUNCTARRAY_H_ */
