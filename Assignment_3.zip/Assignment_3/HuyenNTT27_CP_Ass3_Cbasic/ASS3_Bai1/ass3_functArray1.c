/* Viet 1 h�m tinh dien tich hinh chu nhat cho biet chu vi & duong cheo.*/
/* moi yeu to input deu phai kiem tra*/
#include"ass3_functArray1.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/

/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/
float g_perimeter = 0;/* Chu vi hinh chu nhat */
float g_diagonal_line = 0;/* Duong cheo HCN */
float g_acreage = 1; /* Dien tich HCN */
/*******************************************************************************
 * Code
 ******************************************************************************/
int main()
{
 	do
 	{
 		scanf("\n%f %f",&g_perimeter,&g_diagonal_line);/* Nhap lai vao chu vi va duong cheo*/
	 }while(!checkInput(g_perimeter,g_diagonal_line));

	 calAcreage(g_acreage,g_perimeter,g_diagonal_line);/* Tinh toan dien tich hinh chu nhat*/
}
int checkInput(float g_perimeter,float g_diagonal_line)
{
	if(g_perimeter <=0 || g_diagonal_line <= 0 || g_perimeter <= 2*g_diagonal_line)/*check input conditional*/
	{
		printf("\nThe value inputs are not valid, please re-enter new inputs!\n");
		return 0;/* True return 0*/
	}
	return 1;/* False return 1*/
}
void calAcreage(float g_acreage, float g_perimeter,float g_diagonal_line)/* Tinh dien tich hinh chu nhat*/
{
	g_acreage = (g_perimeter*g_perimeter - 4*g_diagonal_line*g_diagonal_line)/8;
	printf("S %f",g_acreage);/*In ra dien tich */
}
